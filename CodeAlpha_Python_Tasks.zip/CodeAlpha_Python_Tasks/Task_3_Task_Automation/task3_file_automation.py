import os
import shutil

source_folder = "Images"
destination_folder = "JPG_Files"

if not os.path.exists(destination_folder):
    os.mkdir(destination_folder)

for file in os.listdir(source_folder):
    if file.lower().endswith(".jpg"):
        shutil.move(
            os.path.join(source_folder, file),
            os.path.join(destination_folder, file)
        )
        print(file, "moved successfully")

print("JPG file automation completed.")
